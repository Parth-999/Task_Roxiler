export const isAdmin = (role) => role === 'admin';
export const isCustomer = (role) => role === 'customer';
